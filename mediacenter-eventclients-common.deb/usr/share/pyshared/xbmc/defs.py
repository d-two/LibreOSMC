ICON_PATH="/usr/share/pixmaps/xbmc/"
