export PATH="$PATH:/usr/osmc/bin"
